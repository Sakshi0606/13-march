package in.lnt.day2;

public class OrangeHrm_Action
{
	public static void main(String[] args) 
	{
		System.setProperty("webdriver.chrome.driver",".\\Drivers\\chromedriver.exe ");
		WebDriver driver=new ChromeDriver();
		driver.get("http://127.0.0.1:8080/htmldb/f?p=4550:11:17286496247486679950::NO:::");
	}
}
