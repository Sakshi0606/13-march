package TestNGDay12March;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import util.Base;

public class OracleCookieTestWay2 extends Base {
  @Test
  public void f() throws InterruptedException {
	  driver.get("http://127.0.0.1:8080/htmldb");
	  driver.findElement(By.cssSelector("input#P11_USERNAME")).sendKeys("system");
	  driver.findElement(By.cssSelector("input[type = 'password']")).sendKeys("Newuser123");
	  driver.findElement(By.cssSelector("input[value='Login']")).click();
	  driver.manage().deleteAllCookies();
	  driver.navigate().refresh();
	  
	  Assert.assertTrue(driver.findElement(By.name("p_t01")).isDisplayed());
	  Thread.sleep(2000);
  }
}
